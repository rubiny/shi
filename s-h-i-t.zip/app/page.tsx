"use client";

import React, { useState } from 'react';
import Landing from '../components/Landing';
import Dashboard from '../components/Dashboard';

export default function ShitArmy() {
  const [isConnected, setIsConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState("");
  const [isGeneral, setIsGeneral] = useState(false);
  const [generalDaysLeft, setGeneralDaysLeft] = useState(0);

  const connectWallet = () => {
    const mockAddress = "0xSH1T420...69AB";
    setWalletAddress(mockAddress);
    setIsConnected(true);
  };

  const signInWithGoogle = () => {
    setWalletAddress("google-user@shit.army");
    setIsConnected(true);
  };

  const signInWithApple = () => {
    setWalletAddress("apple-user@shit.army");
    setIsConnected(true);
  };

  const disconnectWallet = () => {
    setIsConnected(false);
    setWalletAddress("");
    setIsGeneral(false);
  };

  if (!isConnected) {
    return (
      <Landing 
        onConnect={connectWallet} 
        onGoogle={signInWithGoogle} 
        onApple={signInWithApple} 
      />
    );
  }

  return (
    <Dashboard 
      onDisconnect={disconnectWallet} 
      walletAddress={walletAddress}
      isGeneral={isGeneral}
      generalDaysLeft={generalDaysLeft}
    />
  );
}
