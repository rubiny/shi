"use client";

import React, { useState } from 'react';
import Image from 'next/image';

interface DashboardProps {
  onDisconnect: () => void;
  walletAddress: string;
  isGeneral: boolean;
  generalDaysLeft: number;
}

export default function Dashboard({ onDisconnect, walletAddress, isGeneral, generalDaysLeft }: DashboardProps) {
  const [currentTab, setCurrentTab] = useState<"dashboard" | "offerwall" | "stake" | "market" | "game" | "merch" | "army" | "referral" | "achievements">("dashboard");
  const [shitBalance, setShitBalance] = useState(1240);
  const [points, setPoints] = useState(8740);
  const [totalEarned, setTotalEarned] = useState(3240);
  const [dailyStreak, setDailyStreak] = useState(7);
  const [hasClaimedAirdrop, setHasClaimedAirdrop] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [showAirdrop, setShowAirdrop] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  const triggerSuccess = (message: string) => {
    setSuccessMessage(message);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2600);
  };

  const claimDailyBonus = () => {
    const bonus = 150 + (dailyStreak * 20);
    setShitBalance(shitBalance + bonus);
    setTotalEarned(totalEarned + bonus);
    setDailyStreak(dailyStreak + 1);
    triggerSuccess(`Daily bonus claimed! +${bonus} $SHIT (Streak: ${dailyStreak + 1} days) 🔥`);
  };

  const mainTabs = [
    { id: "dashboard", label: "Dashboard", icon: "🎯" },
    { id: "offerwall", label: "Offerwall", icon: "⚡" },
    { id: "stake", label: "Staking", icon: "🏆" },
    { id: "market", label: "Market", icon: "🛒" },
    { id: "game", label: "Play", icon: "🎮" },
    { id: "merch", label: "Merch", icon: "👕" },
  ];

  const dailyQuests = [
    { title: "Complete 2 offers", progress: 1, max: 2, reward: 300 },
    { title: "Play Tank Shooter", progress: 0, max: 1, reward: 150 },
    { title: "Stake 100 $SHIT", progress: 0, max: 1, reward: 200 },
  ];

  const streakMultiplier = Math.min(Math.floor(dailyStreak / 2) * 5, 35);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/95 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4 cursor-pointer" onClick={() => setCurrentTab("dashboard")}>
            <Image src="/white-shit-logo.png" alt="Shit Army" width={42} height={42} className="rounded-full" />
            <div>
              <div className="font-bold text-2xl tracking-tighter">SHIT.ARMY</div>
              <div className="text-[9px] text-emerald-500 -mt-1 tracking-[1px]">BASE CHAIN</div>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-1 text-sm">
            {mainTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id as any)}
                className={`px-6 py-2.5 rounded-full flex items-center gap-2 transition-all ${currentTab === tab.id ? "bg-white text-black" : "hover:bg-white/10 text-zinc-400"}`}
              >
                <span>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
            
            <div className="relative">
              <button 
                onClick={() => setShowMoreMenu(!showMoreMenu)}
                className="px-5 py-2.5 rounded-full flex items-center gap-2 hover:bg-white/10 text-zinc-400"
              >
                More <span className="text-xs">▼</span>
              </button>
              {showMoreMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-zinc-950 border border-white/10 rounded-2xl py-2 shadow-xl z-50">
                  <button onClick={() => { setCurrentTab("army"); setShowMoreMenu(false); }} className="w-full px-5 py-3 text-left flex items-center gap-3 hover:bg-white/5 text-sm">🪖 Leaderboard</button>
                  <button onClick={() => { setCurrentTab("referral"); setShowMoreMenu(false); }} className="w-full px-5 py-3 text-left flex items-center gap-3 hover:bg-white/5 text-sm">👥 Referrals</button>
                  <button onClick={() => { setCurrentTab("achievements"); setShowMoreMenu(false); }} className="w-full px-5 py-3 text-left flex items-center gap-3 hover:bg-white/5 text-sm">🏅 Badges</button>
                  <div className="border-t border-white/10 my-1"></div>
                  <button onClick={onDisconnect} className="w-full px-5 py-3 text-left flex items-center gap-3 hover:bg-white/5 text-sm text-red-400">Disconnect</button>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:block px-4 py-1.5 bg-zinc-900 rounded-full text-xs border border-white/10 font-mono">
              {walletAddress.length > 18 ? walletAddress.slice(0, 18) + "..." : walletAddress}
            </div>
            {isGeneral && <div className="text-xl">👑</div>}
          </div>
        </div>

        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-black border-t border-white/10 z-50 py-2">
          <div className="flex justify-around text-xs">
            {mainTabs.map((tab) => (
              <button key={tab.id} onClick={() => setCurrentTab(tab.id as any)} className={`flex flex-col items-center px-2 py-1 ${currentTab === tab.id ? "text-emerald-400" : "text-zinc-400"}`}>
                <span className="text-xl mb-0.5">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
            <button onClick={() => setShowMoreMenu(!showMoreMenu)} className="flex flex-col items-center px-2 py-1 text-zinc-400">
              <span className="text-xl mb-0.5">⋯</span>
              More
            </button>
          </div>
        </div>
      </nav>

      <div className="pt-20 pb-24 max-w-7xl mx-auto px-6">
        {/* DASHBOARD */}
        {currentTab === "dashboard" && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
              <div>
                <div className="text-emerald-500 text-sm tracking-[2px]">WELCOME BACK, SOLDIER {isGeneral && "👑"}</div>
                <h1 className="text-6xl font-bold tracking-tight">Dashboard</h1>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-zinc-950 border border-white/10 px-6 py-3 rounded-2xl text-sm flex items-center gap-3">🔥 {dailyStreak} day streak</div>
                <button onClick={claimDailyBonus} className="bg-emerald-600 hover:bg-emerald-500 px-8 py-3 rounded-2xl text-sm font-semibold active:scale-[0.985]">CLAIM DAILY BONUS</button>
              </div>
            </div>

            {isGeneral && (
              <div className="bg-gradient-to-r from-emerald-600 to-emerald-500 rounded-3xl p-6 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xl">👑 GENERAL PASS ACTIVE</div>
                  <div className="text-emerald-100 text-sm">+25% offer rewards • {generalDaysLeft} days remaining</div>
                </div>
                <div className="text-4xl">🔥</div>
              </div>
            )}

            {totalEarned >= 5000 && !hasClaimedAirdrop && (
              <div 
                onClick={() => setShowAirdrop(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-500 rounded-3xl p-6 flex items-center justify-between cursor-pointer hover:brightness-110 transition-all active:scale-[0.985]"
              >
                <div>
                  <div className="font-bold text-xl flex items-center gap-2">🪂 AIRDROP READY</div>
                  <div className="text-purple-100 text-sm">You've earned {totalEarned.toLocaleString()} $SHIT • Claim your reward!</div>
                </div>
                <div className="text-4xl">🎁</div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-zinc-950 border border-white/10 rounded-3xl p-8">
                <div className="text-sm text-zinc-500 mb-1">$SHIT BALANCE</div>
                <div className="text-6xl font-semibold tabular-nums tracking-tighter text-emerald-400">{shitBalance.toLocaleString()}</div>
              </div>
              <div className="bg-zinc-950 border border-white/10 rounded-3xl p-8">
                <div className="text-sm text-zinc-500 mb-1">POINTS</div>
                <div className="text-6xl font-semibold tabular-nums tracking-tighter">{points.toLocaleString()}</div>
                <button className="mt-3 text-xs bg-white/10 px-4 py-1 rounded-full">CONVERT TO $SHIT</button>
              </div>
              <div className="bg-zinc-950 border border-white/10 rounded-3xl p-8">
                <div className="text-sm text-zinc-500 mb-1">CURRENT RANK</div>
                <div className="text-5xl font-bold">Private {isGeneral && "👑"}</div>
                <div className="text-emerald-500 text-sm mt-2">2,160 $SHIT to Sergeant</div>
              </div>
              <div className="bg-zinc-950 border border-white/10 rounded-3xl p-8">
                <div className="text-sm text-zinc-500 mb-1">TOTAL EARNED</div>
                <div className="text-5xl font-semibold tabular-nums">{totalEarned.toLocaleString()}</div>
                <div className="text-xs text-emerald-500">$SHIT all-time {streakMultiplier > 0 && `(+${streakMultiplier}% streak)`}</div>
              </div>
            </div>

            <div className="flex gap-4">
              <button className="flex-1 bg-emerald-600 hover:bg-emerald-500 py-4 rounded-2xl font-semibold text-lg active:scale-[0.985]">BUY $SHIT</button>
              <button className="flex-1 border border-white/30 hover:bg-white/5 py-4 rounded-2xl font-semibold text-lg active:scale-[0.985]">WITHDRAW</button>
            </div>

            {/* AIRDROP PROGRESS */}
            <div className="bg-zinc-950 border border-white/10 rounded-3xl p-9">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="font-semibold text-xl flex items-center gap-3">🪂 YOUR AIRDROP</div>
                  <div className="text-sm text-zinc-400 mt-1">The more you earn, the bigger your reward</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-zinc-500">CURRENT TIER</div>
                  <div className="text-emerald-400 font-semibold">
                    {totalEarned >= 25000 ? "LEGENDARY" : totalEarned >= 10000 ? "EPIC" : totalEarned >= 5000 ? "RARE" : "COMMON"}
                  </div>
                </div>
              </div>

              <div className="bg-black/60 rounded-2xl p-6 mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <div>Progress to next tier</div>
                  <div className="font-mono text-emerald-400">
                    {totalEarned >= 25000 ? "MAX" : totalEarned >= 10000 ? `${totalEarned}/25000` : totalEarned >= 5000 ? `${totalEarned}/10000` : `${totalEarned}/5000`}
                  </div>
                </div>
                <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className="h-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-500" 
                    style={{ 
                      width: totalEarned >= 25000 ? '100%' : 
                             totalEarned >= 10000 ? `${Math.min(((totalEarned - 10000) / 15000) * 100, 100)}%` : 
                             totalEarned >= 5000 ? `${Math.min(((totalEarned - 5000) / 5000) * 100, 100)}%` : 
                             `${Math.min((totalEarned / 5000) * 100, 100)}%` 
                    }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-zinc-500">ESTIMATED AIRDROP</div>
                  <div className="text-3xl font-bold text-purple-400">
                    {totalEarned >= 25000 ? "1,500" : totalEarned >= 10000 ? "600" : totalEarned >= 5000 ? "250" : "50"} $SHIT
                  </div>
                </div>
                
                {totalEarned >= 5000 && !hasClaimedAirdrop ? (
                  <button 
                    onClick={() => setShowAirdrop(true)}
                    className="bg-purple-600 hover:bg-purple-500 px-8 py-3 rounded-2xl font-semibold active:scale-[0.985]"
                  >
                    CLAIM NOW
                  </button>
                ) : (
                  <div className="text-xs text-zinc-500 px-4 py-2 bg-white/5 rounded-full">Claim available at 5,000 $SHIT</div>
                )}
              </div>
            </div>

            {/* DAILY QUESTS */}
            <div className="bg-zinc-950 border border-white/10 rounded-3xl p-9">
              <div className="flex justify-between items-center mb-6">
                <div className="font-semibold text-xl flex items-center gap-3">📅 DAILY QUESTS <span className="text-xs bg-emerald-500/20 text-emerald-400 px-3 py-px rounded">RESET IN 18H</span></div>
                <div className="text-xs text-zinc-500">Complete all for +650 PTS bonus</div>
              </div>
              <div className="space-y-4">
                {dailyQuests.map((q, i) => (
                  <div key={i} className="flex items-center justify-between bg-black/60 rounded-2xl px-6 py-5">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">🎯</div>
                      <div>
                        <div>{q.title}</div>
                        <div className="text-xs text-zinc-500">{q.progress}/{q.max} completed</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-emerald-400 font-mono">+{q.reward} PTS</div>
                      <div className="w-28 h-1.5 bg-white/10 rounded mt-2"><div className="h-1.5 bg-emerald-500 rounded" style={{width: `${(q.progress/q.max)*100}%`}}></div></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div onClick={() => setCurrentTab("offerwall")} className="cursor-pointer bg-zinc-950 border border-white/10 hover:border-emerald-500/60 rounded-3xl p-8 active:scale-[0.985] transition-all">
                <div className="text-5xl mb-6">⚡</div>
                <div className="text-3xl font-semibold">Go to Offerwall</div>
                <div className="text-zinc-400 mt-2">8 offers • Highest: 2,100 PTS {streakMultiplier > 0 && `(+${streakMultiplier}%)`}</div>
              </div>
              <div onClick={() => setCurrentTab("stake")} className="cursor-pointer bg-zinc-950 border border-white/10 hover:border-emerald-500/60 rounded-3xl p-8 active:scale-[0.985] transition-all">
                <div className="text-5xl mb-6">🏆</div>
                <div className="text-3xl font-semibold">Stake $SHIT</div>
                <div className="text-zinc-400 mt-2">48% APY • TVL $1.24M</div>
              </div>
              <div onClick={() => setCurrentTab("game")} className="cursor-pointer bg-zinc-950 border border-white/10 hover:border-emerald-500/60 rounded-3xl p-8 active:scale-[0.985] transition-all">
                <div className="text-5xl mb-6">🎮</div>
                <div className="text-3xl font-semibold">Play &amp; Earn</div>
                <div className="text-zinc-400 mt-2">Free mode + Daily Tournament</div>
              </div>
            </div>
          </div>
        )}

        {/* PLACEHOLDER DLA INNYCH ZAKŁADEK */}
        {currentTab !== "dashboard" && (
          <div className="text-center py-20">
            <div className="text-8xl mb-6">🚧</div>
            <div className="text-4xl font-bold mb-4">{currentTab.charAt(0).toUpperCase() + currentTab.slice(1)} Coming Soon</div>
            <div className="text-zinc-400">This section is fully built in the main app</div>
          </div>
        )}
      </div>

      {showSuccess && (
        <div className="fixed bottom-24 md:bottom-8 left-1/2 -translate-x-1/2 z-[300] bg-emerald-600 text-white px-9 py-4 rounded-2xl flex items-center gap-3 font-medium shadow-2xl">
          ✅ {successMessage}
        </div>
      )}

      {showAirdrop && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-6" onClick={() => setShowAirdrop(false)}>
          <div className="bg-zinc-950 border border-white/20 rounded-3xl max-w-md w-full p-9 text-center" onClick={e => e.stopPropagation()}>
            <div className="text-6xl mb-6">🪂</div>
            <div className="text-4xl font-bold mb-2">Airdrop Claim</div>
            <div className="text-xl text-purple-400 mb-8">You've earned {totalEarned.toLocaleString()} $SHIT</div>
            
            <div className="bg-black/60 rounded-2xl p-6 mb-8">
              <div className="text-sm text-zinc-400 mb-1">YOUR AIRDROP REWARD</div>
              <div className="text-5xl font-bold text-purple-400">
                {totalEarned >= 25000 ? "1,500" : totalEarned >= 10000 ? "600" : "250"} $SHIT
              </div>
            </div>

            <button 
              onClick={() => { setHasClaimedAirdrop(true); setShowAirdrop(false); triggerSuccess("Airdrop claimed! +250 $SHIT 🪂"); }}
              className="w-full py-5 bg-purple-600 hover:bg-purple-500 rounded-2xl font-bold text-lg active:scale-[0.985]"
            >
              CLAIM AIRDROP
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
